const mongoose  = require("mongoose");

const myModelSchema = new mongoose.Schema({
    full_name :{
        type : String,
        required : true,
    },
    username : {
        type : String,
        required : true,
    },
    email : {
        type : String,
        required : true,
    },
    phone : {
        type : Number,
        required : true,
    },
    photo : {
        type : String,
        required : true,
    },
    business_name : {
        type : String,
        required : true,
    },
    address_line1 : {
        type : String,
        required : true,
    },
    address_line2 : {
        type : String,
        required : true,
    },
    city : {
        type : String,
        required : true,
    },
    state : {
        type : String,
        required : true,
    },
    zip : {
        type : String,
        required : true,
    },
    country : {
        type : String,
        required : true,
    },
    about : {
        type : String,
        required : true,
    },
    currency : {
        type : String,
        required : true,
    }
})

// creating table
const Customer = new mongoose.model("Customer",myModelSchema )

module.exports =  Customer;