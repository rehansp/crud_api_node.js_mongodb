const express = require("express")
const app = express()

require("../src/db/conn");
const Customer = require("../src/models/my_model");

const bodyParser = require('body-parser');
// app.use(bodyParser.json());
app.use(express.json());

const port = process.env.PORT || 3000;

// app.get("/", async (req,res) => {
//     res.send("Hello, from rehan");
// })

// post req
app.post("/cust", async (req,res) => {
    try{
        const addNewCust = new Customer(req.body)
        console.log(req.body);
        const insertCust = await addNewCust.save();
        res.status(201).send(insertCust);
        // console.log(insertCust);
    }catch(e){
        res.status(400).send(e);
    }
})

// get req
app.get("/cust", async (req,res) => {
    try{
        const getCustomers = await Customer.find({});
        res.send(getCustomers);
        // console.log(insertCust);
    }catch(e){
        res.status(400).send(e);
    }
})

// get req for individual
app.get("/cust/:id", async (req,res) => {
    try{
        const _id = req.params.id
        const getCust = await Customer.findById(_id);
        res.send(getCust);
        // console.log(insertCust);
    }catch(e){
        res.status(400).send(e);
    }
})

// put request
app.patch("/cust/:id", async (req,res) => {
    try{
        const _id = req.params.id
        const getCust = await Customer.findByIdAndUpdate(_id,req.body,{
            new : true
        });
        console.log(req.body);
        res.send(getCust);
        // console.log(insertCust);
    }catch(e){
        res.status(500).send(e);
    }
})

// delete req
app.delete("/cust/:id", async (req,res) => {
    try{
        const _id = req.params.id
        const getCust = await Customer.findByIdAndDelete(_id);
        console.log(req.body);
        res.send(getCust);
        // console.log(insertCust);
    }catch(e){
        res.status(500).send(e);
    }
})


app.listen(port, () => {
    console.log(`connection is live at port no. ${port}`);
})

module.exports = app;

